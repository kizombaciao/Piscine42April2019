#include "../inc/bsq.h"

int ft_is_num(char c)
{
	return (c >= '0' && c <= '9');
}
